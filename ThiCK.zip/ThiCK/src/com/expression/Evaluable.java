package com.expression;

public interface Evaluable {
    double evaluate();
}
