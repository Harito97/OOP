package oopprinciples.polymorphism;

public class Dog extends Animal {
    public void animalSound() {
        System.out.println("The dog says: bow wow");
    }
}
